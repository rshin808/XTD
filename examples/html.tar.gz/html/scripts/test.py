#!/usr/bin/env python
import datetime as dt
import csv

with open("/var/www/html/scripts/test.txt", "a") as testFile:
    csvW = csv.writer(testFile)
    csvW.writerow([str(dt.datetime.now())])

print str(dt.datetime.now())
