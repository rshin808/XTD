<?php
    system('sudo python /var/www/html/scripts/test.py');
?>
